package com.example.mfoodwastemanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DetaiActivity extends AppCompatActivity {
    EditText ufood,uprize,uphno;

    Button c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detai);
        ufood = (EditText) findViewById(R.id.a);
        uprize = (EditText) findViewById(R.id.b);
        uphno= (EditText) findViewById(R.id.c);
        c=findViewById(R.id.buttonc);

        Intent i = getIntent();
        String rfood = i.getStringExtra("Food");
        String rprize = i.getStringExtra("Prize");
        String rphno = i.getStringExtra("Phno");
        Integer ah =i.getIntExtra("pos",0);






        ufood.setText("Food- "+rfood);
        uprize.setText("Prize- "+rprize);
        uphno.setText("Contact no- "+rphno);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(DetaiActivity.this,"Thankyou for buying",Toast.LENGTH_LONG).show();

            }
        });
    }
}